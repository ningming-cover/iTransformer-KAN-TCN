import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

# 设置中文字体
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC"]
plt.rcParams["axes.unicode_minus"] = False  # 解决负号显示问题


def visualize_two_datasets(file_path1, file_path2, titles=("福建风场数据", "北欧风站数据")):
    try:
        # 读取两个 CSV 文件
        df1 = pd.read_csv(file_path1)
        df2 = pd.read_csv(file_path2)

        # 校验格式
        for i, df in enumerate([df1, df2], 1):
            if df.shape[1] != 2:
                raise ValueError(f"第{i}个 CSV 文件必须包含且仅包含两列数据")

        # 获取列名
        actual_col1, predicted_col1 = df1.columns
        actual_col2, predicted_col2 = df2.columns
        print(f"文件1列名: {actual_col1}, {predicted_col1}")
        print(f"文件2列名: {actual_col2}, {predicted_col2}")

        # 创建画布：4 行 × 2 列 = 8 张图
        fig, axes = plt.subplots(4, 2, figsize=(36, 60))  # 图整体放大
        fig.suptitle('两地风电预测模型对比分析', fontsize=104, fontweight='bold', y=0.995)

        # 定义绘制函数
        def plot_group(df, actual_col, predicted_col, ax_list, title_prefix):
            # ---------------------- 1. 散点图 ----------------------
            ax_list[0].scatter(df[actual_col], df[predicted_col],
                               alpha=0.6, edgecolors='w', s=400)
            min_val = min(df[actual_col].min(), df[predicted_col].min())
            max_val = max(df[actual_col].max(), df[predicted_col].max())
            ax_list[0].plot([min_val, max_val], [min_val, max_val], 'r--', linewidth=16)
            ax_list[0].set_title(f'{title_prefix}：真实值 vs 预测值', fontsize=88, fontweight='bold')
            ax_list[0].set_xlabel(actual_col, fontsize=76, fontweight='bold')
            ax_list[0].set_ylabel(predicted_col, fontsize=76, fontweight='bold')
            ax_list[0].tick_params(axis='both', labelsize=72, width=12, length=28)
            ax_list[0].grid(True, linestyle='--', alpha=0.7, linewidth=8)

            # ---------------------- 2. 折线图 ----------------------
            sample_size = min(100, len(df))
            sample_df = df.head(sample_size)
            ax_list[1].plot(sample_df.index, sample_df[actual_col],
                            label=actual_col, marker='o', markersize=36,
                            linewidth=12, alpha=0.8)
            ax_list[1].plot(sample_df.index, sample_df[predicted_col],
                            label=predicted_col, marker='s', markersize=36,
                            linewidth=12, alpha=0.8)
            ax_list[1].set_title(f'{title_prefix}：前{sample_size}个样本对比', fontsize=88, fontweight='bold')
            ax_list[1].set_xlabel('样本索引', fontsize=76, fontweight='bold')
            ax_list[1].set_ylabel('数值', fontsize=76, fontweight='bold')
            ax_list[1].tick_params(axis='both', labelsize=72, width=12, length=28)
            ax_list[1].legend(fontsize=76, frameon=True, edgecolor='black')
            ax_list[1].grid(True, linestyle='--', alpha=0.7, linewidth=8)

            # ---------------------- 3. 残差散点图 ----------------------
            residuals = df[predicted_col] - df[actual_col]
            ax_list[2].scatter(df[actual_col], residuals,
                               alpha=0.6, edgecolors='w', s=400)
            ax_list[2].axhline(y=0, color='r', linestyle='--', linewidth=16)
            ax_list[2].set_title(f'{title_prefix}：残差散点图', fontsize=88, fontweight='bold')
            ax_list[2].set_xlabel(actual_col, fontsize=76, fontweight='bold')
            ax_list[2].set_ylabel('残差 (预测值 - 真实值)', fontsize=76, fontweight='bold')
            ax_list[2].tick_params(axis='both', labelsize=72, width=12, length=28)
            ax_list[2].grid(True, linestyle='--', alpha=0.7, linewidth=8)

            # ---------------------- 4. 残差直方图 ----------------------
            sns.histplot(residuals, kde=True, ax=ax_list[3], edgecolor='black')
            ax_list[3].axvline(x=0, color='r', linestyle='--', linewidth=16)
            ax_list[3].set_title(f'{title_prefix}：残差直方图', fontsize=88, fontweight='bold')
            ax_list[3].set_xlabel('残差 (预测值 - 真实值)', fontsize=76, fontweight='bold')
            ax_list[3].set_ylabel('频数', fontsize=76, fontweight='bold')
            ax_list[3].tick_params(axis='both', labelsize=72, width=12, length=28)
            ax_list[3].grid(True, linestyle='--', alpha=0.7, linewidth=8, axis='y')

        # 绘制左列（福建风场）与右列（北欧风站）
        plot_group(df1, actual_col1, predicted_col1, axes[:, 0], titles[0])
        plot_group(df2, actual_col2, predicted_col2, axes[:, 1], titles[1])

        # 布局与保存
        plt.tight_layout(rect=[0, 0, 1, 0.98])
        plt.savefig("风电预测两地对比分析_放大版.pdf", bbox_inches='tight', facecolor='white')
        print("✅ 分析图表已保存为 '风电预测两地对比分析_放大版.pdf'")
        plt.show()

    except Exception as e:
        print(f"❌ 发生错误：{str(e)}")


if __name__ == "__main__":
    # 替换为你的两个文件路径
    file_path2 = "MKAN_iTransformer真实值与预测值.csv"
    file_path1 = "EMA-iTransformer真实值与预测值.csv"

    visualize_two_datasets(file_path1, file_path2, titles=("福建", "北欧"))
