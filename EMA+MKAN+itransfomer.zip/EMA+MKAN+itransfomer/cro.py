import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 设置中文字体，确保中文正常显示
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC"]
plt.rcParams["axes.unicode_minus"] = False  # 解决负号显示问题


def plot_heatmaps_separately(file1_path, file2_path):
    try:
        # ---------------------- 处理第一个文件（福建风场）----------------------
        df1 = pd.read_csv(file1_path, nrows=2000)
        if df1.shape[1] < 12:
            raise ValueError("第一个CSV文件至少需要包含12列数据")
        df1_selected = df1.iloc[:, 1:12]
        corr1 = df1_selected.corr()

        # 创建第一个独立图表（保留刻度线，添加内部数字）
        fig1, ax1 = plt.subplots(figsize=(12, 10))  # 加大画布，避免数字拥挤
        cmap = sns.diverging_palette(230, 20, as_cmap=True)

        # 绘制第一张热力图（添加数字，无颜色条，强化刻度线）
        sns.heatmap(
            corr1,
            ax=ax1,
            cmap=cmap,
            annot=True,  # 显示内部数字
            fmt=".2f",   # 保留2位小数
            square=True,
            linewidths=1,  # 加大网格线宽度，与大数字区分
            vmin=-1,
            vmax=1,
            cbar=False,  # 无颜色条
            annot_kws={  # 设置数字大小为20，加粗
                'size': 20,
                'weight': 'bold'
            }
        )

        # 强化刻度线（确保可见）
        ax1.tick_params(
            axis='both',
            labelsize=18,  # 刻度标签稍小于内部数字，避免冲突
            which='major',
            width=3,  # 刻度线宽度加大
            length=6  # 刻度线长度加长
        )
        # 坐标轴标签加粗
        for label in ax1.get_xticklabels():
            label.set_fontweight('bold')
        for label in ax1.get_yticklabels():
            label.set_fontweight('bold')

        # 标题设置（与整体字体协调）
        # ax1.set_title('福建风场数据相关性热力图', fontsize=22, fontweight='bold')

        # 调整布局并保存为第一个PDF
        plt.tight_layout()
        fig1.savefig('fujian_heatmap.pdf', bbox_inches='tight')
        print("福建风场热力图已保存为 'fujian_heatmap.pdf'")

        # ---------------------- 处理第二个文件（北欧风场）----------------------
        df2 = pd.read_csv(file2_path, nrows=2000)
        if df2.shape[1] < 10:
            raise ValueError("第二个CSV文件至少需要包含10列数据")
        df2_selected = df2.iloc[:, 1:10]
        corr2 = df2_selected.corr()

        # 创建第二个独立图表（添加内部数字，保留颜色条）
        fig2, ax2 = plt.subplots(figsize=(12, 10))  # 加大画布
        cmap = sns.diverging_palette(230, 20, as_cmap=True)

        # 绘制第二张热力图（添加数字，保留颜色条）
        sns.heatmap(
            corr2,
            ax=ax2,
            cmap=cmap,
            annot=True,  # 显示内部数字
            fmt=".2f",
            square=True,
            linewidths=1,
            vmin=-1,
            vmax=1,
            cbar=False,  # 无颜色条
            # cbar_kws={
            #     "shrink": .8,
            #     'label': {'size': 18, 'weight': 'bold'}  # 颜色条标签大小
            # },
            annot_kws={  # 数字大小为20，加粗
                'size': 20,
                'weight': 'bold'
            }
        )
        # 强化刻度线（确保可见）
        ax2.tick_params(
            axis='both',
            labelsize=18,  # 刻度标签稍小于内部数字，避免冲突
            which='major',
            width=3,  # 刻度线宽度加大
            length=6  # 刻度线长度加长
        )
        # 坐标轴标签加粗

        for label in ax2.get_xticklabels():
            label.set_fontweight('bold')
        for label in ax2.get_yticklabels():
            label.set_fontweight('bold')

        # 标题设置
        # ax2.set_title('北欧风场数据相关性热力图', fontsize=22, fontweight='bold')

        # 调整布局并保存为第二个PDF
        plt.tight_layout()
        fig2.savefig('beiyou_heatmap.pdf', bbox_inches='tight')
        print("北欧风场热力图已保存为 'beiyou_heatmap.pdf'")

        # 显示两个图表
        plt.show()

        return corr1, corr2

    except FileNotFoundError as e:
        print(f"错误：找不到文件 - {str(e)}")
        return None, None
    except Exception as e:
        print(f"处理文件时发生错误：{str(e)}")
        return None, None


if __name__ == "__main__":
    file1_path = "data/newdata.csv"  # 第一个CSV文件路径
    file2_path = "data/newdata_sudan.csv"  # 第二个CSV文件路径
    plot_heatmaps_separately(file1_path, file2_path)